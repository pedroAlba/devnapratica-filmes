# Montando o ambiente				
descrever como configurar o ambiente de desenvolvimento do projeto. 
