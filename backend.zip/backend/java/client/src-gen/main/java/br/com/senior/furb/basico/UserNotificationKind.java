/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

/**
 * User notification kind.
 */
public enum UserNotificationKind {
    Operational,
    Management,
    News
}
