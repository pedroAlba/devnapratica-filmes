/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

/**
 * The generation of this class is deprecated, use BasicUserIdentifier implementation or implements UserIdentifier yourself
 */
@Deprecated
public class CredentialsProviderImpl implements CredentialsProvider {
	
	private String username;
	
	private String tenant;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getTenant() {
		return tenant;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

}