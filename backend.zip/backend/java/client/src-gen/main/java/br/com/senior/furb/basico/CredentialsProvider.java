/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

import br.com.senior.sdl.user.UserIdentifier;

/**
 * The generation of this class is deprecated, use UserIdentifier direct instead
 */
@Deprecated
public interface CredentialsProvider extends UserIdentifier {
	

	void setUsername(String username);

	void setTenant(String tenant);

}