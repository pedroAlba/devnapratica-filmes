/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

public enum FileFormat {
    CSV,
    FLAT,
    JSON,
    XML
}
