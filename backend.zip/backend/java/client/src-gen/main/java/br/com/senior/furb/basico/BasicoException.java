/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

/**
 * RuntimeException do serviçoBasico
 */
public class BasicoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public BasicoException(String message, Throwable cause) {
        super(message, cause);
    }

	public BasicoException(String message) {
        super(message);
    }

}

