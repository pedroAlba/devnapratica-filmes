/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

public enum HookFunction {
    BEFORE_PARSE,
    BEFORE_CONVERSION,
    ON_ERROR,
    VALIDATE
}
