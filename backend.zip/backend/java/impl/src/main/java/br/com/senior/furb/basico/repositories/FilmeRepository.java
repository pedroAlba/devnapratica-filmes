package br.com.senior.furb.basico.repositories;

import org.springframework.stereotype.Repository;

import br.com.senior.furb.basico.FilmeBaseRepository;

@Repository
public interface FilmeRepository extends FilmeBaseRepository {

}
