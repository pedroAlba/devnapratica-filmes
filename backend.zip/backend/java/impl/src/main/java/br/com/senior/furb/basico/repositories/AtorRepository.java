package br.com.senior.furb.basico.repositories;

import org.springframework.stereotype.Repository;

import br.com.senior.furb.basico.AtorBaseRepository;

@Repository
public interface AtorRepository extends AtorBaseRepository{

}
