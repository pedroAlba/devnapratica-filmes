package br.com.senior.furb.basico.properties;

public interface FurbBasicoPropertyConsts {
	/**
	 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
	 *
	 * This file has one constant for each property key for the domain/service "Furb/Basico".
	 */
	 
	 /* Current version */
	 String VERSION = "3.0.0";
	 
	 /* Service properties */
	 interface Service {
	 	String DB_URL = "db.url";
	 	String DB_USERNAME = "db.username";
	 	String DB_PASSWORD = "db.password";
	 	String DB_SCHEMA_NAME = "db.schema.name";
	 }
}
