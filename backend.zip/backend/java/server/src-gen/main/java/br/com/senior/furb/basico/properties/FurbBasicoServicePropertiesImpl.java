package br.com.senior.furb.basico.properties;


/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 *
 */

public class FurbBasicoServicePropertiesImpl extends BaseProperties {
	
	public static String getDbUrl() {
		return getConfigs().getString(FurbBasicoPropertyConsts.Service.DB_URL);
	}
	
	public static void setDbUrl(String value) {
		getConfigs().setProperty(FurbBasicoPropertyConsts.Service.DB_URL, value);
	}				
	
	public static String getDbUsername() {
		return getConfigs().getString(FurbBasicoPropertyConsts.Service.DB_USERNAME);
	}
	
	public static void setDbUsername(String value) {
		getConfigs().setProperty(FurbBasicoPropertyConsts.Service.DB_USERNAME, value);
	}				
	
	public static String getDbPassword() {
		return getConfigs().getString(FurbBasicoPropertyConsts.Service.DB_PASSWORD);
	}
	
	public static void setDbPassword(String value) {
		getConfigs().setProperty(FurbBasicoPropertyConsts.Service.DB_PASSWORD, value);
	}				
	
	public static String getDbSchemaName(String defaultValue) {
		return getConfigs().getString(FurbBasicoPropertyConsts.Service.DB_SCHEMA_NAME, defaultValue);
	}
	
	public static void setDbSchemaName(String value) {
		getConfigs().setProperty(FurbBasicoPropertyConsts.Service.DB_SCHEMA_NAME, value);
	}				
	
	
}
