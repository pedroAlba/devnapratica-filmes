package br.com.senior.furb.basico.properties;

import br.com.senior.messaging.configuration.ServiceConfiguration;
import br.com.senior.messaging.model.ServiceContext;

/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 *
 */

public class BaseProperties {
	
	/**
	 * Get current service configurations for the context
	 * */
	protected static ServiceConfiguration getConfigs() {
		return ServiceContext.get().getCurrentConfigurations().get();
	}
	
}
