/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

import br.com.senior.messaging.customspringdata.BaseQueryDslJpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface AtorBaseRepository extends BaseQueryDslJpaRepository<AtorEntity, java.util.UUID> {
	
}
