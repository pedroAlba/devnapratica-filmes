/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

import br.com.senior.messaging.model.SubscriptionDescription;

@SubscriptionDescription(domain="platform", service="field_customization", event="fieldCustomizationModified", subscribeAll=true)
public interface FieldCustomizationModified extends br.com.senior.platform.fieldcustomization.FieldCustomizationModified {
    
}
