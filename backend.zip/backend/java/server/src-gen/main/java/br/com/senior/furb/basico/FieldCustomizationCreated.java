/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 */
package br.com.senior.furb.basico;

import br.com.senior.messaging.model.SubscriptionDescription;

@SubscriptionDescription(domain="platform", service="field_customization", event="fieldCustomizationCreated", subscribeAll=true)
public interface FieldCustomizationCreated extends br.com.senior.platform.fieldcustomization.FieldCustomizationCreated {
    
}
