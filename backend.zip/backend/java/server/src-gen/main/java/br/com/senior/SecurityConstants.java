package br.com.senior;

public class SecurityConstants {
	
	public static final String ENTITY_SECURITY_ACTION_CREATE = "Incluir";
	public static final String ENTITY_SECURITY_ACTION_UPDATE = "Editar";
	public static final String ENTITY_SECURITY_ACTION_DELETE = "Excluir";
	public static final String ENTITY_SECURITY_ACTION_VIEW = "Visualizar";

}
