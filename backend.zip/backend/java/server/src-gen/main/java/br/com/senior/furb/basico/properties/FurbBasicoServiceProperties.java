package br.com.senior.furb.basico.properties;


/**
 * This is a generated file. DO NOT EDIT ANY CODE HERE, YOUR CHANGES WILL BE LOST.
 *
 */

public interface FurbBasicoServiceProperties {
	
	public String getDbUrl();
	public void setDbUrl(String value);
	
	public String getDbUsername();
	public void setDbUsername(String value);
	
	public String getDbPassword();
	public void setDbPassword(String value);
	
	public String getDbSchemaName(String defaultValue);
	public void setDbSchemaName(String value);
	
	
}
