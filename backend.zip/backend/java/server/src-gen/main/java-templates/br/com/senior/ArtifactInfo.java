package br.com.senior;

public class ArtifactInfo {
	
	private static final String VERSION = "develop-SNAPSHOT";
	
	public static String getVersion() {
		return VERSION;
	}

}

